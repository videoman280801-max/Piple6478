package com.piple64.browser

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognizerIntent
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.net.URLEncoder
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val VOICE_REQ = 64
        val ENGINES = linkedMapOf(
            "DuckDuckGo" to "https://duckduckgo.com/",
            "Google" to "https://www.google.com/search"
        )
        val BLOCKED = hashSetOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "googletagmanager.com", "googletagservices.com",
            "adservice.google.com", "adnxs.com", "adsrvr.org", "taboola.com", "outbrain.com",
            "criteo.com", "criteo.net", "scorecardresearch.com", "quantserve.com",
            "connect.facebook.net", "hotjar.com", "mixpanel.com", "segment.io", "amplitude.com",
            "an.yandex.ru", "mc.yandex.ru", "moatads.com", "rubiconproject.com", "pubmatic.com",
            "openx.net", "casalemedia.com", "advertising.com", "adform.net", "smartadserver.com",
            "2mdn.net", "zedo.com", "popads.net", "propellerads.com", "mgid.com", "revcontent.com",
            "adcolony.com", "app-measurement.com", "bat.bing.com", "ads.twitter.com",
            "analytics.twitter.com", "ads.linkedin.com", "px.ads.linkedin.com", "clarity.ms",
            "fullstory.com", "mouseflow.com", "crazyegg.com", "newrelic.com", "branch.io",
            "appsflyer.com", "adjust.com", "ads.yahoo.com", "adtech.com", "yieldmo.com"
        )
    }

    private lateinit var web: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var shieldView: TextView
    private var blockedCount = 0

    private val prefs: SharedPreferences by lazy { getSharedPreferences("piple64", Context.MODE_PRIVATE) }
    private val engine: String get() = prefs.getString("engine", "DuckDuckGo") ?: "DuckDuckGo"
    private val adblock: Boolean get() = prefs.getBoolean("adblock", true)
    private val httpsOnly: Boolean get() = prefs.getBoolean("https", true)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun isBlocked(host: String): Boolean {
        var h = host.lowercase(Locale.ROOT)
        while (true) {
            if (h in BLOCKED) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#14141F")
        window.navigationBarColor = Color.parseColor("#14141F")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#14141F"))
            fitsSystemWindows = true
        }

        // ---- верхняя панель ----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        fun iconBtn(text: String, onClick: () -> Unit) = TextView(this).apply {
            this.text = text
            textSize = 19f
            setTextColor(Color.parseColor("#DDDDDD"))
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(6), dp(9), dp(6))
            setOnClickListener { onClick() }
        }

        bar.addView(iconBtn("◀") { if (web.canGoBack()) web.goBack() })
        bar.addView(iconBtn("⟳") { web.reload() })

        urlBar = EditText(this).apply {
            hint = "Адрес или запрос"
            setHintTextColor(Color.parseColor("#777790"))
            setTextColor(Color.parseColor("#EEEEEE"))
            textSize = 14f
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#222236"))
                setStroke(dp(1), Color.parseColor("#33334D"))
            }
            setOnEditorActionListener { v, _, _ ->
                navigate(v.text.toString().trim())
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                v.clearFocus()
                true
            }
        }
        bar.addView(urlBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(4), 0, dp(4), 0)
        })

        bar.addView(iconBtn("🎤") { startVoice() })
        shieldView = iconBtn("🛡0") { openMenu() }.apply { textSize = 13f }
        bar.addView(shieldView)
        bar.addView(iconBtn("⋮") { openMenu() })
        root.addView(bar)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = android.view.View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        // ---- WebView ----
        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        setupWebView()
        val data = intent?.data
        if (data != null) web.loadUrl(data.toString()) else goHome()
    }

    private fun setupWebView() {
        web.setBackgroundColor(Color.parseColor("#0F0F17"))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setGeolocationEnabled(false)
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            mediaPlaybackRequiresUserGesture = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                progress.progress = p
                progress.visibility = if (p in 1..99) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                if (adblock && isBlocked(req.url.host ?: "")) {
                    blockedCount++
                    runOnUiThread { shieldView.text = "🛡$blockedCount" }
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                if (httpsOnly && u.scheme == "http") {
                    view.loadUrl(u.buildUpon().scheme("https").build().toString())
                    return true
                }
                return false
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!urlBar.hasFocus()) {
                    urlBar.setText(if (url.contains("piple64.local")) "" else url)
                }
            }
        }
    }

    private fun startPageHtml(): String {
        val action = ENGINES[engine]!!
        return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>piple64</title>
<style>
body{margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;
background:radial-gradient(circle at 30% 20%,#2b1f4a,#0f0f17 60%);font-family:sans-serif;color:#eee}
h1{font-size:54px;margin:0 0 22px;letter-spacing:-2px;background:linear-gradient(90deg,#8b5cf6,#22d3ee);
-webkit-background-clip:text;color:transparent}
form{width:86vw;max-width:520px}
input{width:100%;box-sizing:border-box;padding:15px 20px;border-radius:30px;border:1px solid #3a3a55;
background:#1a1a28;color:#fff;font-size:16px;outline:none}
input:focus{border-color:#8b5cf6}
p{opacity:.5;font-size:13px;margin-top:16px}
</style></head><body>
<h1>piple64</h1>
<form action="$action" method="get"><input name="q" placeholder="Поиск через $engine…"></form>
<p>лёгкий · быстрый · защищённый</p></body></html>"""
    }

    private fun goHome() {
        web.loadDataWithBaseURL("https://piple64.local/", startPageHtml(), "text/html", "utf-8", null)
        urlBar.setText("")
    }

    private fun navigate(t: String) {
        if (t.isEmpty()) return
        val url = when {
            t.contains(" ") || (!t.contains(".") && !t.contains("://")) ->
                ENGINES[engine]!! + "?q=" + URLEncoder.encode(t, "UTF-8")
            t.contains("://") -> t
            else -> "https://$t"
        }
        web.loadUrl(url)
    }

    // ---- голосовой поиск (системный, без доп. разрешений) ----
    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите…")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(i, VOICE_REQ)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Голосовой ввод недоступен на этом устройстве", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQ && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                urlBar.setText(text)
                navigate(text)
            }
        }
    }

    // ---- меню / настройки ----
    private fun openMenu() {
        val items = arrayOf(
            "Поисковик: $engine",
            "Блокировка рекламы: " + if (adblock) "вкл" else "выкл",
            "Только HTTPS: " + if (httpsOnly) "вкл" else "выкл",
            "Домой",
            "Очистить данные"
        )
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> pickEngine()
                1 -> prefs.edit().putBoolean("adblock", !adblock).apply()
                2 -> prefs.edit().putBoolean("https", !httpsOnly).apply()
                3 -> goHome()
                4 -> {
                    web.clearCache(true)
                    web.clearHistory()
                    CookieManager.getInstance().removeAllCookies(null)
                    WebStorage.getInstance().deleteAllData()
                    Toast.makeText(this, "Данные очищены", Toast.LENGTH_SHORT).show()
                }
            }
        }.show()
    }

    private fun pickEngine() {
        val names = ENGINES.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Поисковик")
            .setSingleChoiceItems(names, names.indexOf(engine)) { d, i ->
                prefs.edit().putString("engine", names[i]).apply()
                d.dismiss()
                Toast.makeText(this, "Поисковик: ${names[i]}", Toast.LENGTH_SHORT).show()
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }

    override fun onPause() {
        web.onPause()
        web.pauseTimers()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.resumeTimers()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
